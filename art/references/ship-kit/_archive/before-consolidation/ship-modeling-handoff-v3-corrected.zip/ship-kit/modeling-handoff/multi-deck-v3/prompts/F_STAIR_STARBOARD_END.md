# F_STAIR_STARBOARD_END

Use contract.json and meshes/F_STAIR_STARBOARD_END.obj. Exact geometry overrides concept art. Preserve interface coordinates within 1 mm. Flat floors: no raised posts or perimeter curbs. Uniform-height wall tiers: no raised transom. Warm broad wooden planks, dark iron, restrained grain, toon shading. Keep stair openings and landings unchanged. Deliver model, collision separately, socket empties and measured bounds.
